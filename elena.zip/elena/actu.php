
<?php include 'header.php'; ?>

<div id="imageBackground" style="background-image:url(images/fond-mochi1.png);"></div>

<div class="frame frameCenter">
	<a href="/" title="Accueil">
        <img class="logo" src="../images/logo-baramochis.png" alt="logo mochi" />
	</a>

	<a class="SoustitrePage" href="#">
		<br> Nom de la page <br>
		<img class="ImagePage" src="../images/snoopy2.png" alt="Image Test" />
	</a>
	<div class="ContenuPage">
		<p><span>Element 1 :</span> texte</p>
		<p><span>Element 2 :</span> texte <span>&bull;</span> texte</p>
	</div>
</div>
	

<?php include 'footer.php'; ?>