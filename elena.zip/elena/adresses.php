
<?php include 'header.php'; ?>

<div id="imageBackground" style="background-image:url(images/fond-mochi1.png);"></div>

<div class="frame frameCenter">
	<a href="/" title="Accueil">
        <img class="logo" src="../images/logo-baramochis.png" alt="logo mochi" />
	</a>

	<p class="SoustitrePage"><br> BOUTIQUES</p><br>
	
	<img class="ImagePage" src="../images/mochi-plateau.png"/>
	
	<div class="ContenuPage">
		<p><span>Boutique en ligne</span> 
			<br>ouverture dès 10 000 mochis pré-commandés </p>
		<br><br>
		<p><span>Boutique physique à Paris </span> 
			<br>ouverture peu après la boutique en ligne</p>
	</div>
</div>
	
<?php include 'pre-footer.php'; ?>
<?php include 'footer.php'; ?>

