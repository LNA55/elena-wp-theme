$(document).ready(function(){
  //$('.bullet-after').after('<li class="menuBull">•</li>');
  var bullets = $('.bullet-after');
  for (i = 0; i < bullets.length; i++) {
    console.log(bullets[i]);
      //bullets[i].after('<li class="menuBull">•</li>');
  }
});
