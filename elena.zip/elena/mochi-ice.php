
<?php include 'header.php'; ?>

<div id="imageBackground" style="background-image:url(images/fond-mochi1.png);"></div>

<div class="frame frameCenter">
	<a href="/" title="Accueil">
        <img class="logo" src="../images/logo-baramochis.png" alt="logo mochi" />
	</a>

	<a class="SoustitrePage" href="#">
		<br> Mochis glacés <br>
		<img class="ImagePage" src="../images/mochi-lychee.png" alt="Mochi glacé" />
	</a>
	<div class="ContenuPage">
		<p><span>Description</span> <br>
			Petites boules de crèmes glacées et de sorbets de qualité, enrobées de pâte de riz gluant.
			</p><br>
		<p><span>Parfums</span> <br>
			incontournable thé vert <span>&bull;</span> puissant vanille <span>&bull;</span> sensuel gingembre <span>&bull;</span> exotique lytchee <span>&bull;</span> cremeux moka <span>&bull;</span> gourmand caramel au beurre salé <span>&bull;</span> décadent nougatine <span>&bull;</span> acidulé citron vert <span>&bull;</span> rafraichissant citron basilic <span>&bull;</span> et notre préféré : le yaourt 0%
			</p><br>
		<p><span>Consommation et conservation</span> <br>
		 	se déguste immédiatement après achat sur place ou à emporter <span>&bull;</span> se congèle ou se déguste immédiatement après livraison par nos camions réfrigérés <span>&bull;</span> Ne jamais recongeler un produit décongelé 
		 	</p>
		
	</div>
</div>
	

<?php include 'footer.php'; ?>