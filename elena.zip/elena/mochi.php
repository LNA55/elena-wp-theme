
<?php include 'header.php'; ?>

<div id="imageBackground" style="background-image:url(images/fond-mochi1.png);"></div>

<div class="frame frameCenter">
	<a href="/" title="Accueil">
        <img class="logo" src="../images/logo-baramochis.png" alt="logo mochi" />
	</a>

	<a class="SoustitrePage" href="#">
		<br> Nos gammes de mochis <br>
		<img class="ImagePage" src="../images/mochi-chocolat.png" alt="Image Test" />
	</a>
	<div class="ContenuPage">
		<p><span>Mochi glacés </span> seront en vente à 2,80€ pièce <span>&bull;</span> découvrir les parfums <a href="http://mochideclension.com/mochi-ice">ici</a></p>
		<p><span>Mochi à la crème </span> seront en vente à partir de 3,00€ pièce <span>&bull;</span> découvrir les parfums <a href="http://mochideclension.com/mochi-cream">ici</a></p>
	</div>
</div>
	
<?php include 'pre-footer.php'; ?>
<?php include 'footer.php'; ?>