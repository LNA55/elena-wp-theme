<section>

  <section class="lanewsletter">
    <div class="frameBottom">
      <div class="action">
	   <div class="row">
              <div class="formLine formText ">
          			<!-- Begin MailChimp Signup Form -->
          				<span id="mc_embed_signup">
            			<p class="SoustitrePage2">Entrez votre email ici pour être averti du lancement </p>
            				<form action="https://mochideclension.us9.list-manage.com/subscribe/post?u=4061a4baecad74df28fa80780&amp;id=54e061d53f" 
            					method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate style="display:inline">
              					<input type="text" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="Entrez ici votre adresse email" required style="display:inline">
                				<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                				<!-- <div><input type="text" name="b_4061a4baecad74df28fa80780_54e061d53f" tabindex="-1" value=""></div> --> 
              						<span class="clear">
                  					<input type="submit" value="Envoyer" name="subscribe" id="mc-embedded-subscribe" class="buttonLight" style="display:inline">
                  					</span>
            				</form>
          				</span>
        			   <!--End mc_embed_signup-->
              </div> <!-- closes formLine -->
	   </div> <!-- closes row -->
	</div> <!-- closes action -->
    </div> <!-- closes frameBottom -->
  </section>

</section>


